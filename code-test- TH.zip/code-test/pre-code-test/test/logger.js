const expect = require('chai').expect;
const loggerfile = require('../logger');
const useloggerfile = require('../useLogger');
const logger = loggerfile.logger;



describe('Logger', function () {

	// Testing Mocha/Chai returning proper results 
	it('Love test cases, lets make sure Mocha is validating true', function () {
		expect(true).to.be.true;
	});
	//complete
	it('LEVELS should return an object', function () {
		let results = loggerfile.LEVELS;

		expect(results).to.be.a('object');
	});
	//complete
	it('LEVELS should return these constant values', function () {
		let results = loggerfile.LEVELS;

		expect(results).to.deep.equal({INFO: 'info', DEBUG: 'debug', ERROR: 'error', WARN: 'warning'});
	});
	//complete
	it('logger should be a function', function () {
		let results = loggerfile.logger;
		expect(results).to.be.a('function');
	});
	//complete
	it('logger should have root, data, and level arguments', function () {
		let results = new loggerfile.logger({ root: 'driver', data: 'stuff', level: 'error'});
	
		expect(results).to.have.all.keys('root', 'data', 'level');
	});

	it('data info should pass through function unchanged', function () {
		let results = new loggerfile.logger({ root: 'driver', data: 'stuff', level: 'error'});
	
		expect(results).to.have.property('data').and.equal('stuff').and.be.a('string');
	});

	  



	describe('useLogger', function () {	

	const yaml = useloggerfile.yaml;
	const yamlLogger = useloggerfile.yamlLogger;	
	const fileLogger = useloggerfile.fileLogger;
	const rootLogger = useloggerfile.rootLogger;

		it('fs const in not undefined', function() {
		let results = useloggerfile.fs;

	    expect(results).to.not.be.undefined;
		});

		it('yaml const in not undefined', function () {
		let results = useloggerfile.yaml;

		expect(results).to.not.be.undefined;
		});	

		it('yamlLogger should output this is some yaml' , function () {
		let results = yamlLogger.data;

		expect(results).to.equal('This is some yaml');
		});

		it('fileLogger level should output debug' , function () {
		let results = fileLogger.level;

		expect(results).to.equal('debug');
		});	

		it('should return level error' , function () {
		let results = new useloggerfile.logger({ root: 'driver', data: 'stuff', level: 'error'});
			
		//console.log(results);
		expect(results).to.have.property('level').and.equal('error').and.be.a('string');
		});	
		
	});

});

//var results = new useloggerfile.logger({ root: 'driver' }).transport('warning', 'This is some yaml? too');
		//console.log(results);
		//console.log(fileLogger.level);